### AnyKernel3 Ramdisk Mod Script
## osm0sis @ xda-developers

### AnyKernel setup
# global properties
properties() { '
kernel.string=DaisyForGaming v4.9.337-DFG2
do.devicecheck=1
do.modules=0
do.systemless=1
do.cleanup=1
do.cleanuponabort=0
device.name1=daisy
device.name2=Mi_A2_Lite
device.name3=
device.name4=
device.name5=
supported.versions=
supported.patchlevels=
supported.vendorpatchlevels=
'; } # end properties


### AnyKernel install
## boot files attributes
boot_attributes() {
set_perm_recursive 0 0 755 644 $RAMDISK/*;
set_perm_recursive 0 0 750 750 $RAMDISK/init* $RAMDISK/sbin;
} # end attributes

# boot shell variables
BLOCK=/dev/block/bootdevice/by-name/boot;
IS_SLOT_DEVICE=0;
RAMDISK_COMPRESSION=auto;
PATCH_VBMETA_FLAG=auto;

# import functions/variables and setup patching - see for reference (DO NOT REMOVE)
. tools/ak3-core.sh;

ui_print "                                    "
ui_print "======================================"
ui_print "        DFG - DaisyForGaming          "
ui_print "         Kernel v4.9.337               "
ui_print "======================================"
ui_print " "
ui_print "Developed by: JUBAIR HOSEN"
ui_print "Device: Xiaomi Mi A2 Lite (daisy)"
ui_print " "
ui_print "Features included:"
ui_print " - CPU Governors (Schedutil, Interactive)"
ui_print " - BFQ I/O Scheduler"
ui_print " - KCAL Color Control"
ui_print " - GPU Frequency Control"
ui_print " - Gaming Charge Limiter"
ui_print " - Dynamic Fsync Control"
ui_print " - zRAM Support (lz4)"
ui_print " - TCP BBR Congestion Control"
ui_print " - KallSyms Hardening"
ui_print " - DFG Controller sysfs (/sys/devices/platform/dfg)"
ui_print " - Thermal self-protection override"
ui_print " - Wakelock Inspector Support"
ui_print " "
ui_print "Installing kernel..."
ui_print " "

# boot install
dump_boot;

write_boot;
## end boot install

ui_print " "
ui_print "Installation complete!"
ui_print "Reboot and use DFG Controller app to configure features."
ui_print " "
ui_print "Thank you for using DaisyForGaming"
ui_print "         - JUBAIR HOSEN"


